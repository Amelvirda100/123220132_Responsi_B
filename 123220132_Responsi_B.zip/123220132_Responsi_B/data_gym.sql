-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 21 Bulan Mei 2024 pada 03.32
-- Versi server: 10.3.16-MariaDB
-- Versi PHP: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `data_gym`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_gym`
--

CREATE TABLE `tabel_gym` (
  `pemilik` varchar(40) NOT NULL,
  `alat` varchar(50) NOT NULL,
  `telepon` varchar(17) NOT NULL,
  `waktu` int(4) NOT NULL,
  `biaya` int(12) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tabel_gym`
--

INSERT INTO `tabel_gym` (`pemilik`, `alat`, `telepon`, `waktu`, `biaya`, `id`) VALUES
('ahmad ahqil', 'barbel 5 kg', '081329246200', 2, 100000, 1);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tabel_gym`
--
ALTER TABLE `tabel_gym`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tabel_gym`
--
ALTER TABLE `tabel_gym`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
