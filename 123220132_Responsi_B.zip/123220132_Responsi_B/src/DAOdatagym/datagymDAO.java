/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOdatagym;

import DAOImplement.datagymimplement;
import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import koneksi.connector;
import model.*;

public class datagymDAO {
    
    Connection connection;
    int total=0, biaya, waktu;
    int hargadasar = 50000;
    int hargatambahan = 25000;
    final String select = "SELECT*FROM 'data_gym' ('pemilik', 'alat', 'telepon', 'waktu', 'biaya') VALUES(?,?,?,?,?);";
    
    public datagymDAO(){
    connection=connector.connection();
}
    public List<datagym>gettAll(){
        List<datagym> dp = null;
        try{
            dp = newArrayList<datagym>getAll();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while(rs.next()){
                datagym p = new datagym();
                p.setPemilik(rs.getString("Pemilik"));
                p.setAlat(rs.getString("Alat"));
                p.setTelepon(rs.getString("Telepon"));
                p.setPemilik(rs.getString("Pemilik"));
                p.setWaktu(rs.getInt("Waktu"));
                p.setWaktu(rs.getInt("Biaya"));
                dp.add(p);
            }
            
        }
        catch(SQLException ex){
            Logger.getLogger(datagymDAO.class.getPemilik()).log(Level.SEVERE, null, ex);
        }
            return dp;    
    }
    
    public void insert(datagym p){
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatemet(insert,Statement.RETURN_GENERATED_KEYS);
            
        }
    }
}

