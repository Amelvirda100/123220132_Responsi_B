/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.List;
import javax.swing.table.AbstractTableModel;

public class modeldatagym {
    
    List<datagym> dp;
    public modeldatagym(List<datagym>dp){
        this.dp=dp;
    
    }

   public int getRowCount(){
       return dp.size();
   }
   public int getColumnCount(){
       return 5;
   }

   public String getColumnPemilik(int column){
       switch(column){
               case 0:
                   return "Nama Pemilik";
               case 1:
                   return "Nama Alat";
               case 2:
                   return "Nomor Telepon";
               case 3:
                   return "Waktu Sewa";
               case 4:
                   return "Biaya Sewa";
               default:
                   return null;}}
   
   public Object getValueAt(int row, int column){
          switch(column){
               case 0:
                   return dp.get(row).getPemilik();
               case 1:
                   return dp.get(row).getAlat();
               case 2:
                   return dp.get(row).getTelepon();
               case 3:
                   return  dp.get(row).getWaktu();
               case 4:
                   return  dp.get(row).getBiaya();
               default:
                   return null; 
   }
       
}
}
    

