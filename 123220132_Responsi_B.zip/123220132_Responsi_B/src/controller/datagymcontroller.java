/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import DAOImplement.datagymimplement;
import java.util.List;
import DAOdatagym.datagymDAO;
import java.util.logging.Logger;
import view.MainView;
import model.*;

public class datagymcontroller {
    MainView frame;
    datagymimplement implementgym;
    List<datagym> dp;
    
    public void isitabrl(){
        dp = implementgym.gettAll();
        modeltabeldatagym mp = new modeltabeldatagym(dp);
        frame.getTabelgym().setModel(mp);
    }
}
