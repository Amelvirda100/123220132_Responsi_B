/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOImplement;

import java.util.List;
import model.*;

public interface datagymimplement {
    public void insert(datagym dp);
    public void update(datagym dp);
    public void delete(String Pemilik);
    public List<datagym>gettAll();
}
